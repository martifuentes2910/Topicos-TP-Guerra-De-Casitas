#include "KyD.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    Juego juego;
    int opcion;
    srand((unsigned)time(NULL));
    juego.medidor=0;

    while (1) {
        printf("\n=== Knights & Demons ===\n");
        printf("1) Nueva ronda (modo clasico)\n");
        printf("2) Nueva ronda (modo tiempo real teclado)\n");
        printf("3) Cargar partida\n");
        printf("4) Ver medidor\n");
        printf("5) Salir\n");
        opcion = leer_entero("Opcion",1,5);

        if (opcion==1 || opcion==2) {
            int size = leer_entero("Tama�o (1=4x4, 2=6x6, 3=8x8)",1,3);
            if (size==1) juego.filas=juego.cols=4;
            else if (size==2) juego.filas=juego.cols=6;
            else juego.filas=juego.cols=8;

            int diff = leer_entero("Dificultad: \n1=f�cil=>Pikas:5, Tiempo: 90s \n2=medio =>P:3, T:75s \n3=dif�cil=>P:1, T:60s)",1,3);
            juego.dificultad=diff;
            juego.pikas=(diff==1)?5:(diff==2)?3:1;
            juego.tiempoMax=(diff==1)?90:(diff==2)?75:60;

            if (opcion==1) jugar_ronda(&juego);
            else jugar_ronda_teclado(&juego);
        }
        else if (opcion==3) {
            Tablero *t=NULL;
            if (cargar_partida(&juego,&t)) {
                printf("Partida cargada (pero continua jugando en consola).\n");
                mostrar_tablero(t);
                liberar_tablero(t);
            } else printf("No se pudo cargar partida.\n");
        }
        else if (opcion==4) printf("Medidor actual: %d\n", juego.medidor);
        else break;
    }
    return 0;
}

