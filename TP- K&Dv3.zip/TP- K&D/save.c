#include "KyD.h"
#include <stdio.h>

void guardar_partida(const Juego *j, const Tablero *t) {
    FILE *f = fopen("partida.save", "wb");
    if (!f) return;
    fwrite(j, sizeof(Juego), 1, f);
    for (int i=0;i<t->filas;i++)
        fwrite(t->cells[i], sizeof(char), t->cols, f);
    fclose(f);
}

int cargar_partida(Juego *j, Tablero **t) {
    FILE *f = fopen("partida.save", "rb");
    if (!f) return 0;
    fread(j, sizeof(Juego), 1, f);
    *t = crear_tablero(j->filas, j->cols);
    for (int i=0;i<j->filas;i++)
        fread((*t)->cells[i], sizeof(char), j->cols, f);
    fclose(f);
    return 1;
}
