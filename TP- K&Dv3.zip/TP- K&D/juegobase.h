#ifndef JUEGOBASE_H_INCLUDED
#define JUEGOBASE_H_INCLUDED

//SAVE//
void guardar_partida(const Juego *j, const Tablero *t);
int cargar_partida(Juego *j, Tablero **t);

//JUEGO//
typedef struct {
    int dificultad;
    int pikas;
    int tiempoMax;
    int medidor;
    int filas;
    int cols;
} Juego;

void jugar_ronda(Juego *j);           // modo cl�sico
void jugar_ronda_teclado(Juego *j);   // modo tiempo real
int leer_entero(const char *prompt, int min, int max);

//TABLERO//
typedef struct {
    int filas;
    int cols;
    char **cells;
} Tablero;

Tablero *crear_tablero(int filas, int cols);
void liberar_tablero(Tablero *t);
void init_tablero_aleatorio(Tablero *t);
void mostrar_tablero(const Tablero *t);
void toggle_cross(Tablero *t, int r, int c);
int tablero_completo_con(const Tablero *t, char ch);

#endif // JUEGOBASE_H_INCLUDED
