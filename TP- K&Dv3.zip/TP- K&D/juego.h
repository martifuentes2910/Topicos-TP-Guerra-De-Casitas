#ifndef JUEGO_H
#define JUEGO_H
#include "tablero.h"

typedef struct {
    int dificultad;
    int pikas;
    int tiempoMax;
    int medidor;
    int filas;
    int cols;
} Juego;

void jugar_ronda(Juego *j);           // modo cl�sico
void jugar_ronda_teclado(Juego *j);   // modo tiempo real
int leer_entero(const char *prompt, int min, int max);

#endif
// JUEGO_H_INCLUDED
