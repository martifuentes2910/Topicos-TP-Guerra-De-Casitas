#ifndef TABLERO_H
#define TABLERO_H

typedef struct {
    int filas;
    int cols;
    char **cells;
} Tablero;

Tablero *crear_tablero(int filas, int cols);
void liberar_tablero(Tablero *t);
void init_tablero_aleatorio(Tablero *t);
void mostrar_tablero(const Tablero *t);
void toggle_cross(Tablero *t, int r, int c);
int tablero_completo_con(const Tablero *t, char ch);

#endif


