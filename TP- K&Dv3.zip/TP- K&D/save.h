#ifndef SAVE_H
#define SAVE_H
#include "juego.h"
#include "tablero.h"

void guardar_partida(const Juego *j, const Tablero *t);
int cargar_partida(Juego *j, Tablero **t);

#endif
 // SAVE_H_INCLUDED
