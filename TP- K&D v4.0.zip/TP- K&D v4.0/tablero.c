#include "KyD.h"
#include <stdio.h>
#include <stdlib.h>

Tablero *crear_tablero(int filas, int cols) {
    int i;
    Tablero *t = malloc(sizeof(Tablero));
    if (!t) return NULL;
    t->filas = filas;
    t->cols = cols;
    t->cells = malloc(sizeof(char*) * filas);
    for (i = 0; i < filas; i++) {
        t->cells[i] = malloc(sizeof(char) * cols);
    }
    return t;
}

void liberar_tablero(Tablero *t) {
    int i;
    if (!t) return;
    for (i = 0; i < t->filas; i++) free(t->cells[i]);
    free(t->cells);
    free(t);
}

void init_tablero_aleatorio(Tablero *t) {
    int i, j;
    for (i = 0; i < t->filas; i++)
        for (j = 0; j < t->cols; j++)
            t->cells[i][j] = (rand()%2) ? 'C' : 'D';
}

void mostrar_tablero(const Tablero *t) {
    int i, j;
    for (i = 0; i < t->filas; i++) {
        for (j = 0; j < t->cols; j++) {
            printf(" %c ", t->cells[i][j]);
        }
        printf("\n");
    }
}

void toggle_cross(Tablero *t, int r, int c) {
    int dr[5] = {0, -1, 1, 0, 0};
    int dc[5] = {0, 0, 0, -1, 1};
    int k;
    for (k = 0; k < 5; k++) {
        int nr = r+dr[k], nc = c+dc[k];
        if (nr>=0 && nr<t->filas && nc>=0 && nc<t->cols) {
            t->cells[nr][nc] = (t->cells[nr][nc]=='C') ? 'D' : 'C';
        }
    }
}

int tablero_completo_con(const Tablero *t, char ch) {
    int i, j;
    for (i = 0; i < t->filas; i++)
        for (j = 0; j < t->cols; j++)
            if (t->cells[i][j] != ch) return 0;
    return 1;
}
