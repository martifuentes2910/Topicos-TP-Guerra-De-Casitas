#include "KyD.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <conio.h>
#include <windows.h>
void mover_cursor_inicio() {
    COORD coord = {0, 0};
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
#else
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
void mover_cursor_inicio() {
    printf("\033[H");
    fflush(stdout);
}
int kbhit(void) {
    struct termios oldt, newt;
    int ch, oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if (ch != EOF) { ungetc(ch, stdin); return 1; }
    return 0;
}
#endif

/* ==================== Lectura segura con fgets ==================== */
int leer_entero(const char *prompt, int min, int max) {
    char buffer[64];
    long val;
    char *endptr;
    int valido = 0;
    while (!valido) {
        printf("%s (%d-%d): ", prompt, min, max);
        if (!fgets(buffer, sizeof(buffer), stdin)) continue;
        val = strtol(buffer, &endptr, 10);
        if (endptr == buffer || val < min || val > max) {
            printf("Entrada invalida.\n");
        } else {
            valido = 1;
        }
    }
    return (int)val;
}
/* ==================== Configurar Juego ==================== */
void configurar_juego(Juego *juego) {
    static const int tamanios[] = {4, 6, 8};
    static const int pikas[] = {5, 3, 1};
    static const int tiempos[] = {90, 75, 60};

    int size = leer_entero("Tamanio: \n1 = 4x4, \n2 = 6x6, \n3 = 8x8", 1, 3);
    juego->filas = juego->cols = tamanios[size - 1];

    int diff = leer_entero("Dificultad: \n1 = Facil => Pikas:5, Tiempo: 90s \n2 = Medio => P:3, T:75s \n3 = Dificil => P:1, T:60s", 1, 3);
    juego->dificultad = diff;
    juego->pikas = pikas[diff - 1] +  juego->victorias;
    juego->tiempoMax = tiempos[diff - 1];
}

/* ==================== Modo teclado tiempo real ==================== */
void jugar_ronda_teclado(Juego *j) {
    Tablero *t = crear_tablero(j->filas, j->cols);
    if (!t) {
        printf("Error: No se pudo crear el tablero\n");
        return;
    }
    int cursor_r = 0, cursor_c = 0;
    time_t inicio = time(NULL);
    int jugando = 1;
    int limite = j->tiempoMax;

    init_tablero_aleatorio(t);

 #ifdef _WIN32
    system("cls");
#else
    printf("\033[2J");
    printf("\033[H");
#endif

    while (jugando) {
        mover_cursor_inicio(); // evita parpadeo

        // Dibujar tablero
        for (int i = 0; i < t->filas; i++) {
            for (int k = 0; k < t->cols; k++) {
                if (i == cursor_r && k == cursor_c)
                    printf("[%c]", t->cells[i][k]);
                else
                    printf(" %c ", t->cells[i][k]);
            }
            printf("\n");
        }

        printf("Pikas: %d | Medidor: %d\n", j->pikas, j->medidor);
        printf("Controles: WASD o flechas mover | Espacio cruz | P pika | Q salir\n");

        int tiempo_usado = (int)difftime(time(NULL), inicio);
        int tiempo_restante = limite - tiempo_usado;
        printf("Tiempo restante: %d s\n", tiempo_restante);

        if (tiempo_restante <= 0) {
            system("cls");
            mover_cursor_inicio();
            printf("\nSe acabo el tiempo. Los demonios ganan la ronda.\n");
            j->medidor--;
            j->victorias = 0; //SE RESETEA LA RACHA Y EL BONUS DE PIKAS
            break;
        }

        // Entrada de teclado
        if (kbhit()) {
#ifdef _WIN32
            int tecla = _getch();
#else
            int tecla = getchar();
#endif
            if (tecla == 'w' || tecla == 72) cursor_r--;
            else if (tecla == 's' || tecla == 80) cursor_r++;
            else if (tecla == 'a' || tecla == 75) cursor_c--;
            else if (tecla == 'd' || tecla == 77) cursor_c++;
            else if (tecla == ' ') toggle_cross(t, cursor_r, cursor_c);
            else if (tecla == 'p' || tecla == 'P') {
                if (j->pikas > 0) {
                    t->cells[cursor_r][cursor_c] =
                        (t->cells[cursor_r][cursor_c] == 'C') ? 'D' : 'C';
                    j->pikas--;
                }
            } else if (tecla == 'q' || tecla == 'Q') {
                printf("\nSaliste de la ronda.\n");
                jugando = 0;
            }

    // Limitar cursor dentro de los bordes
            if (cursor_r < 0) cursor_r = 0;
            if (cursor_r >= j->filas) cursor_r = j->filas - 1;
            if (cursor_c < 0) cursor_c = 0;
            if (cursor_c >= j->cols) cursor_c = j->cols - 1;
        }

#ifdef _WIN32
        Sleep(60);
#else
        usleep(60000);
#endif

        // Verificar fin de partida
        if (tablero_completo_con(t, 'C'))
        {
            printf("\033[2J");
            mover_cursor_inicio();
            printf("\nCaballeros ganan la ronda.\n");
            j->medidor++;
            j->victorias++; //BONUS +1 PIKA POR CADA VICTORIA DE CABALLEROS
            break;
        } else if (tablero_completo_con(t, 'D'))
        {
            printf("\033[2J");
            mover_cursor_inicio();
            printf("\nDemonios ganan la ronda.\n");
            j->medidor--;
            //SI GANAN LOS DEMONIOS, EL BONUS DE PIKA POR RACHA DE VICTORIA SE MANTIENE IGUAL
            break;
        }
    }

    liberar_tablero(t);
}
