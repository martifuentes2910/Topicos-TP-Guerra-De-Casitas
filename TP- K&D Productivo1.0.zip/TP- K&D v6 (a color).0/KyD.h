#ifndef KNIGHTS_H
#define KNIGHTS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>

/* ==========================================================
   ESTRUCTURAS PRINCIPALES
   ========================================================== */
typedef struct {
    int filas;
    int cols;
    char **cells;
} Tablero;

typedef struct {
    int dificultad;   /* 1=f�cil, 2=medio, 3=dif�cil */
    int pikas;        /* cantidad de pikas disponibles */
    int tiempoMax;    /* segundos de l�mite (opcional) */
    int medidor;      /* balance global del juego */
    int filas;
    int cols;
    int victorias;
} Juego;

/* ==========================================================
   FUNCIONES DE TABLERO
   ========================================================== */
Tablero *crear_tablero(int, int);
void liberar_tablero(Tablero *);
void init_tablero_aleatorio(Tablero *);
void mostrar_tablero(const Tablero *);
void toggle_cross(Tablero *, int, int);
int tablero_completo_con(const Tablero *, char);

/* ==========================================================
   FUNCIONES DE JUEGO
   ========================================================== */
void limpiar_pantalla();
void configurar_juego(Juego *);
int leer_entero(const char *, int, int);
void jugar_ronda_teclado(Juego *);   /* modo en tiempo real con teclado */
//void mostrar_barra_medidor(int);
void mostrar_barra_tablero_color(Juego *, Tablero *);
void mostrar_barra_medidor_color(Juego *);

#endif /* KNIGHTS_H */

