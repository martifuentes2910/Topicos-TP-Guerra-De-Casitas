#include "KyD.h"

int main()
{
    Juego juego = {0};  // Inicializar toda la estructura a cero
    int opcion;
    srand((unsigned)time(NULL));

    do
    {
        printf("\n=== Knights & Demons ===\n");
        printf("1) Nueva ronda (modo tiempo real teclado)\n");
        printf("2) Ver medidor\n");
        printf("3) Salir\n");

        printf("RACHA (+Bonus Pikas) = %d \n", juego.victorias);

        opcion = leer_entero("Opcion", 1, 3);

        switch(opcion)
        {
        case 1:
            configurar_juego(&juego);
            jugar_ronda_teclado(&juego);
            break;

        case 2:
            printf("Medidor actual: %d\n", juego.medidor);
            break;

        case 3:
            printf("Saliendo del juego...\n");
            break;
        }
    }
    while (opcion != 3);

    return 0;
}

