#include "KyD.h"

int main() {
    Juego j;
    int opcion;
    srand(time(NULL));

    do {
#ifdef _WIN32
        system("cls");
#else
        printf("\033[2J\033[H");
#endif
        printf("==== Knights & Demons ====\n");
                printf("En el lejano mundo de Garnik, Bakelor, Se�or de la Guerra y Rey de los Caballeros Solteros,\ncomanda valerosamente los ej�rcitos contra elmalvado Se�or de la Oscuridad.\nDesgraciadamente, Bakelor ha tenido unaccidente dom�stico cuando sal�a del ba�o y\nha tenido que darse de baja, justo el d�a que comienza una batalla important�sima. Ante la\nimposibilidad de aplazarla, no ha tenido m�s remedio que dejarlo todo en manos de su\nbecario favorito: t�... �Aceptas el desaf�o? \n");
        printf("1) Jugar nueva partida\n");
        printf("2) Ver medidor\n");
        printf("3) Salir\n");
        opcion = leer_entero("Opcion", 1, 3);

        if (opcion == 1) {
#ifdef _WIN32
            system("cls");
#else
            printf("\033[2J\033[H");
#endif
            printf("Seleccione dificultad:\n");
            printf("1) Facil  (mas tiempo y pikas)\n");
            printf("2) Medio  (balanceado)\n");
            printf("3) Dificil (menos tiempo y pikas)\n");
            int dif = leer_entero("Opcion", 1, 3);

            if (dif == 1) { j.pikas = 5; j.tiempoMax = 90; }
            else if (dif == 2) { j.pikas = 3; j.tiempoMax = 75; }
            else { j.pikas = 1; j.tiempoMax = 60; }
            j.dificultad = dif;
            j.medidor = 0; // reinicia medidor al comenzar nueva partida

            printf("\nSeleccione tamano del tablero:\n");
            printf("1) 4x4\n");
            printf("2) 6x6\n");
            printf("3) 8x8\n");
            int t = leer_entero("Opcion", 1, 3);
            if (t == 1) { j.filas = 4; j.cols = 4; }
            else if (t == 2) { j.filas = 6; j.cols = 6; }
            else { j.filas = 8; j.cols = 8; }

            jugar_partida(&j);
        }
        else if (opcion == 2) {
            printf("Medidor actual: %d\n", j.medidor);
#ifdef _WIN32
            system("pause");
#else
            printf("Presione Enter para continuar...");
            getchar();
#endif
        }

    } while (opcion != 3);

    printf("Fin del juego.\n");
    return 0;
}
