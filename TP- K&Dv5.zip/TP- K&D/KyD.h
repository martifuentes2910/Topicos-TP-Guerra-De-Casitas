#ifndef KNIGHTS_H
#define KNIGHTS_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ANCHO 20
#define LIMITE (ANCHO / 2)

/* ==========================================================
   ESTRUCTURAS PRINCIPALES
   ========================================================== */
typedef struct {
    int filas;
    int cols;
    char **cells;
} Tablero;

typedef struct {
    int dificultad;   /* 1=f�cil, 2=medio, 3=dif�cil */
    int pikas;        /* cantidad de pikas disponibles */
    int tiempoMax;    /* segundos de l�mite (opcional) */
    int medidor;      /* balance global del juego */
    int filas;
    int cols;
} Juego;

/* ==========================================================
   FUNCIONES DE TABLERO
   ========================================================== */
Tablero *crear_tablero(int filas, int cols);
void liberar_tablero(Tablero *t);
void init_tablero_aleatorio(Tablero *t);
void mostrar_tablero(const Tablero *t);
void intercambio(Tablero *t, int r, int c);
int tablero_completo_con(const Tablero *t, char ch);

/* ==========================================================
   FUNCIONES DE JUEGO
   ========================================================== */
void jugar_partida(Juego *j);
int leer_entero(const char *prompt, int min, int max);
void jugar_ronda(Juego *j);           /* modo cl�sico por fila/columna */
void jugar_ronda_teclado(Juego *j);   /* modo en tiempo real con teclado */
void mostrar_barra_medidor(int valor);

#endif /* KNIGHTS_H */

