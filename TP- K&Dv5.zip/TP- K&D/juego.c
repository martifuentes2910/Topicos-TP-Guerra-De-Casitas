#include "KyD.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <conio.h>
#include <windows.h>
void mover_cursor_inicio() {
    COORD coord = {0, 0};
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
#else
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>


void mover_cursor_inicio()
{
    printf("\033[H");
    fflush(stdout);
}
int kbhit(void)
{
    struct termios oldt, newt;
    int ch, oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if (ch != EOF) { ungetc(ch, stdin); return 1; }
    return 0;
}
#endif

/* ==================== Lectura segura con fgets ==================== */
int leer_entero(const char *prompt, int min, int max)
{
    char buffer[64];
    long val;
    char *endptr;
    int valido = 0;
    while (!valido) {
        printf("%s (%d-%d): ", prompt, min, max);
        if (!fgets(buffer, sizeof(buffer), stdin)) continue;
        val = strtol(buffer, &endptr, 10);
        if (endptr == buffer || val < min || val > max) {
            printf("Entrada invalida.\n");
        } else {
            valido = 1;
        }
    }
    return (int)val;
}

/* ==================== Partida completa ==================== */
void jugar_partida(Juego *j)
{
    int seguir = 1;
    Tablero *t = crear_tablero(j->filas, j->cols);

    while (seguir) {
#ifdef _WIN32
        system("cls");
#else
        printf("\033[2J"); printf("\033[H");
#endif

        printf("Comienza una nueva ronda!\n");
        printf("1) Modo clasico\n");
        printf("2) Modo teclado tiempo real\n");
        int modo = leer_entero("Seleccione modo", 1, 2);

        /* Reiniciar tablero antes de cada ronda */
        init_tablero_aleatorio(t);

        if (modo == 1)
            jugar_ronda(j);
        else
            jugar_ronda_teclado(j);

        printf("\nRonda finalizada.\n");
        printf("Medidor actual: %d | Pikas: %d\n", j->medidor, j->pikas);

        printf("\nDesea continuar jugando esta partida?\n");
        printf("1) Siguiente ronda (mismo tablero y dificultad)\n");
        printf("2) Terminar partida\n");

        int opcion = leer_entero("Opcion", 1, 2);
        if (opcion == 2) {
            seguir = 0;
        }
    }

    liberar_tablero(t);

    /* Fin de la partida */
    printf("\nLa partida ha terminado.\n");
    printf("Medidor final: %d | Pikas restantes: %d\n", j->medidor, j->pikas);

    if (j->medidor >= LIMITE)
    {
    printf("\n*** CABALLEROS GANAN LA PARTIDA ***\n");
    mostrar_barra_medidor(j->medidor);
    seguir = 0;
    } else if (j->medidor <= -LIMITE)
        {
    printf("\n*** DEMONIOS GANAN LA PARTIDA ***\n");
    mostrar_barra_medidor(j->medidor);
    seguir = 0;
        }


    printf("\nDesea:\n");
    printf("1) Jugar otra partida nueva\n");
    printf("2) Volver al menu principal\n");

    int opcion = leer_entero("Opcion", 1, 2);
    if (opcion == 1) {
        jugar_partida(j);  // comienza otra partida nueva con nueva dificultad y tablero
    }
}

/* ==================== Modo clasico ==================== */
void jugar_ronda(Juego *j) {
    Tablero *t = crear_tablero(j->filas, j->cols);
    int r, c, opcion;
    time_t inicio = time(NULL);

    init_tablero_aleatorio(t);

#ifdef _WIN32
    system("cls");
#else
    printf("\033[2J");
    printf("\033[H");
#endif

    while (1) {
        system("cls||clear");
        mostrar_tablero(t);
        printf("Pikas: %d | Medidor: %d\n", j->pikas, j->medidor);
        int tiempo = (int)difftime(time(NULL), inicio);
        printf("Tiempo restante: %d\n", j->tiempoMax - tiempo);
        if (tiempo >= j->tiempoMax) {
            printf("Tiempo agotado. Los demonios ganan la ronda.\n");
            j->medidor--;
            break;
        }

        printf("1) Invertir en cruz\n2) Usar pika\n3) Salir ronda\n");
        opcion = leer_entero("Opcion", 1, 3);

        if (opcion == 1) {
            r = leer_entero("Fila", 0, j->filas - 1);
            c = leer_entero("Columna", 0, j->cols - 1);
            intercambio(t, r, c);
        } else if (opcion == 2) {
            if (j->pikas > 0) {
                r = leer_entero("Fila", 0, j->filas - 1);
                c = leer_entero("Columna", 0, j->cols - 1);
                t->cells[r][c] = (t->cells[r][c] == 'C') ? 'D' : 'C';
                j->pikas--;
            } else {
                printf("Sin pikas disponibles.\n");
            }
        } else break;

        if (tablero_completo_con(t, 'C')) {
            printf("Caballeros ganan la ronda.\n");
            j->medidor++;
            j->pikas++;
            break;
        } else if (tablero_completo_con(t, 'D')) {
            printf("Demonios ganan la ronda.\n");
            j->medidor--;
            break;
        }
    }
    liberar_tablero(t);
}

/* ==================== Modo teclado tiempo real ==================== */
void jugar_ronda_teclado(Juego *j) {
    Tablero *t = crear_tablero(j->filas, j->cols);
    int cursor_r = 0, cursor_c = 0;
    time_t inicio = time(NULL);
    int jugando = 1;
    int limite = j->tiempoMax;

    init_tablero_aleatorio(t);

 #ifdef _WIN32
    system("cls");
#else
    printf("\033[2J");
    printf("\033[H");
#endif

    while (jugando) {
        mover_cursor_inicio(); // evita parpadeo

        // Dibujar tablero
        for (int i = 0; i < t->filas; i++) {
            for (int k = 0; k < t->cols; k++) {
                if (i == cursor_r && k == cursor_c)
                    printf("[%c]", t->cells[i][k]);
                else
                    printf(" %c ", t->cells[i][k]);
            }
            printf("\n");
        }

        mostrar_barra_medidor(j->medidor);
        printf("Pikas: %d\n", j->pikas);

        printf("Controles: \nWASD o flechas = mover | Espacio = cruz | P = pika | X = salir\n");

        int tiempo_usado = (int)difftime(time(NULL), inicio);
        int tiempo_restante = limite - tiempo_usado;
        printf("Tiempo restante: %d s\n", tiempo_restante);



        if (tiempo_restante <= 0) {
            mover_cursor_inicio();
                printf("\033[2J");
                printf("\033[H");
            printf("\nSe acabo el tiempo. Los demonios ganan la ronda.\n");
            j->medidor--;
            break;
        }

        // Entrada de teclado
        if (kbhit()) {
#ifdef _WIN32
            int tecla = _getch();
#else
            int tecla = getchar();
#endif
            if (tecla == 'w' || tecla == 72) cursor_r--;
            else if (tecla == 's' || tecla == 80) cursor_r++;
            else if (tecla == 'a' || tecla == 75) cursor_c--;
            else if (tecla == 'd' || tecla == 77) cursor_c++;
            else if (tecla == ' ') intercambio(t, cursor_r, cursor_c);
            else if (tecla == 'p' || tecla == 'P') {
                if (j->pikas > 0) {
                    t->cells[cursor_r][cursor_c] =
                        (t->cells[cursor_r][cursor_c] == 'C') ? 'D' : 'C';
                    j->pikas--;
                }
            } else if (tecla == 'x' || tecla == 'X') {
                printf("\nSaliste de la ronda.\n");
                jugando = 0;
            }

            if (cursor_r < 0) cursor_r = 0;
            if (cursor_r >= j->filas) cursor_r = j->filas - 1;
            if (cursor_c < 0) cursor_c = 0;
            if (cursor_c >= j->cols) cursor_c = j->cols - 1;
        }

#ifdef _WIN32
        Sleep(60);
#else
        usleep(60000);
#endif

        // Verificar fin de partida
        if (tablero_completo_con(t, 'C'))
        {
            printf("\033[2J");
            printf("\033[H");
            mover_cursor_inicio();
            printf("\nCaballeros ganan la ronda.\n");
            j->medidor++;
            j->pikas++;
            break;
        } else if (tablero_completo_con(t, 'D'))
        {
            printf("\033[2J");
            printf("\033[H");
            mover_cursor_inicio();
            printf("\nDemonios ganan la ronda.\n");
            j->medidor--;
            break;
        }
    }

    liberar_tablero(t);
}

void mostrar_barra_medidor(int valor)
{
    int pos_ind = (ANCHO / 2) + valor;
    if (pos_ind < 0) pos_ind = 0;
    if (pos_ind >= ANCHO) pos_ind = ANCHO - 1;

    printf("CABALLEROS ");
    for (int i = 0; i < ANCHO; i++) {
        if (i == pos_ind)
            printf("X");   // indicador de posicion
        else
            printf("=");  // barra continua
    }
    printf(" DEMONIOS\n");

    // Mostrar ventaja textual
    if (valor > 0)
        printf("Ventaja de los CABALLEROS (+%d)\n", valor);
    else if (valor < 0)
        printf("Ventaja de los DEMONIOS (%d)\n", valor);
    else
        printf("Equilibrio entre fuerzas\n");
}

